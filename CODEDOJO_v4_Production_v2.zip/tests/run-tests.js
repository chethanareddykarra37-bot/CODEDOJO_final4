process.env.NODE_ENV = "test";
process.env.DB_PATH = ":memory:";

const assert = require("assert");
const http = require("http");
const app = require("../backend/server");
const db = require("../backend/db/database");
const { getDailyProblem } = require("../backend/services/dailyDispatcher");
const DojoUtils = require("../src/modules/utils");
const DojoSandbox = require("../src/modules/sandbox");
const DojoState = require("../src/modules/state");
const DojoUI = require("../src/modules/ui");

function request(port, method, path, body = null, token = null) {
  return new Promise((resolve, reject) => {
    const payload = body ? JSON.stringify(body) : null;
    const headers = { "Content-Type": "application/json" };
    if (payload) headers["Content-Length"] = Buffer.byteLength(payload);
    if (token) headers["Authorization"] = `Bearer ${token}`;

    const req = http.request({ hostname: "127.0.0.1", port, path, method, headers }, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(data) });
        } catch (_e) {
          resolve({ status: res.statusCode, body: data });
        }
      });
    });
    req.on("error", reject);
    if (payload) req.write(payload);
    req.end();
  });
}

// Lightweight Headless DOM Harness for Frontend Component Verification
function createMockDOM() {
  const elements = new Map();
  const makeEl = (id) => {
    const classSet = new Set();
    return {
      id,
      textContent: "",
      innerHTML: "",
      value: "",
      classList: {
        add: (c) => classSet.add(c),
        remove: (c) => classSet.delete(c),
        contains: (c) => classSet.has(c)
      }
    };
  };

  [
    "statusBanner", "streakCount", "solvedCount", "failCount", "sprintTimer",
    "sessionBadge", "loginBtn", "logoutBtn", "usernameInput", "passcodeInput",
    "dailyDateBadge", "problemDetails", "hintBox", "squadDisplay",
    "leaderboardBody", "pageIndicator", "heatmapGrid", "tagFilter",
    "diffFilter", "problemSelect", "langSelect", "codeEditor"
  ].forEach((id) => elements.set(id, makeEl(id)));

  elements.get("tagFilter").value = "ALL";
  elements.get("diffFilter").value = "ALL";
  elements.get("langSelect").value = "javascript";

  global.document = {
    getElementById: (id) => {
      if (!elements.has(id)) elements.set(id, makeEl(id));
      return elements.get(id);
    }
  };
  return elements;
}

async function runAllTests() {
  console.log("==========================================================");
  console.log("   CODEDOJO v4.0 FULL-STACK & TRANSACTIONAL TEST SUITE    ");
  console.log("==========================================================");

  await db.ready;

  // 1. Date-Based Daily Problem Dispatcher Tests
  const day1 = getDailyProblem(new Date("2026-11-20T10:00:00Z"));
  const day2 = getDailyProblem(new Date("2026-11-21T10:00:00Z"));
  assert.strictEqual(day1.date, "2026-11-20");
  assert.strictEqual(day2.date, "2026-11-21");
  assert.notStrictEqual(day1.problem.id, day2.problem.id, "Consecutive UTC dates should rotate daily problem");
  console.log("✔ 1. Date-Based Daily Problem Dispatcher (UTC rotation): PASSED");

  // 2. Python + JavaScript Live Sandbox Execution Tests
  const jsRes = DojoSandbox.executeDirect(
    "function solve(nums, target) { return nums[0] + nums[1] === target; }",
    [{ args: [[2, 7], 9], expected: true }],
    "javascript"
  );
  assert.strictEqual(jsRes.status, "OK");
  assert.strictEqual(jsRes.results[0].passed, true);

  const pyRes = DojoSandbox.executeDirect(
    "def solve(nums, target):\n    seen = set()\n    for n in nums:\n        if (target - n) in seen:\n            return True\n        seen.add(n)\n    return False",
    [
      { args: [[2, 7, 11, 15], 9], expected: true },
      { args: [[1, 2, 3], 10], expected: false }
    ],
    "python"
  );
  assert.strictEqual(pyRes.status, "OK");
  assert.strictEqual(pyRes.results.every((r) => r.passed), true);
  console.log("✔ 2. JavaScript & Python Live Sandbox Assertions: PASSED");

  // 3. Database Transaction Atomicity & Rollback Verification
  let rolledBack = false;
  try {
    await db.withTransaction(async (tx) => {
      await tx.run("UPDATE squads SET score = 99999 WHERE name = 'Binary Beasts'");
      throw new Error("Simulated mid-transaction failure");
    });
  } catch (_e) {
    rolledBack = true;
  }
  assert.strictEqual(rolledBack, true);
  const beastsAfter = await db.get("SELECT score FROM squads WHERE name = 'Binary Beasts'");
  assert.strictEqual(beastsAfter.score, 460, "Transaction must roll back partial writes on error");
  console.log("✔ 3. SQLite ACID Transaction Commit & Rollback Safety: PASSED");

  // 4. End-to-End API Integration Tests (Auth, Joi, Daily, Transactional Submissions, Pagination)
  const server = app.listen(0);
  const port = server.address().port;

  try {
    // Invalid Joi payload
    const badReg = await request(port, "POST", "/api/auth/login", { handle: "a", password: "12" });
    assert.strictEqual(badReg.status, 400);

    // Register & JWT issuance
    const reg = await request(port, "POST", "/api/auth/login", { handle: "nina_algo", password: "SecretPassword99" });
    assert.strictEqual(reg.status, 201);
    assert.ok(reg.body.token);
    const token = reg.body.token;

    // Daily endpoint
    const dailyRes = await request(port, "GET", "/api/daily?date=2026-11-21");
    assert.strictEqual(dailyRes.status, 200);
    assert.strictEqual(dailyRes.body.date, "2026-11-21");

    // Create squad & atomic submission
    const sqRes = await request(port, "POST", "/api/squads", { name: "Quantum Coders", accessCode: "QBIT26" }, token);
    assert.strictEqual(sqRes.status, 200);

    const subRes = await request(
      port,
      "POST",
      "/api/submissions",
      {
        problemId: "p1",
        language: "python",
        code: "def solve(nums, target): return True",
        squadName: "Quantum Coders",
        passed: true,
        points: 150
      },
      token
    );
    assert.strictEqual(subRes.status, 200);
    assert.strictEqual(subRes.body.awarded, 150);
    assert.strictEqual(subRes.body.user.streak, 2);
    const qSquad = subRes.body.squads.find((s) => s.name === "Quantum Coders");
    assert.strictEqual(qSquad.score, 170);

    // Paginated leaderboard
    const lbRes = await request(port, "GET", "/api/leaderboard?page=1&limit=2");
    assert.strictEqual(lbRes.status, 200);
    assert.strictEqual(lbRes.body.squads.length, 2);
    assert.strictEqual(lbRes.body.total, 3);
    console.log("✔ 4. Express API Integration, Auth, Pagination & Submissions: PASSED");
  } finally {
    server.close();
  }

  // 5. Frontend UI & Utility Automated Component Tests
  const dom = createMockDOM();
  global.DojoState = DojoState;
  global.DojoUtils = DojoUtils;

  DojoState.user = { handle: "nina_algo", token: "jwt" };
  DojoState.streak = 5;
  DojoState.failCount = 3;
  DojoState.solvedIds = ["p1", "p2"];
  DojoUI.populateProblemSelect();
  DojoUI.renderAll();

  assert.strictEqual(dom.get("streakCount").textContent, "5 days");
  assert.strictEqual(dom.get("solvedCount").textContent, "2");
  assert.strictEqual(dom.get("hintBox").classList.contains("hidden"), false, "AI hint should unlock after 3 failures");
  assert.ok(dom.get("leaderboardBody").innerHTML.includes("Binary Beasts"));
  assert.strictEqual(DojoUtils.similarityRatio("abc", "abc"), 100);
  console.log("✔ 5. Frontend UI Rendering, AI Hint Unlock & Plagiarism Utils: PASSED");

  console.log("==========================================================");
  console.log("   ALL 5 FULL-STACK VERIFICATION SUITES PASSED (100%)     ");
  console.log("==========================================================");
}

runAllTests().catch((err) => {
  console.error("Test Suite Failed:", err);
  process.exit(1);
});
