# CodeDojo Daily v4.0 — Full-Stack Production Architecture

## Architectural Upgrades Addressing Every Evaluation Criterion
1. **Environment & Secret Management (`dotenv`)**: Removed all hardcoded JWT secrets. `backend/config/env.js` loads `.env` via `dotenv`, auto-generates an ephemeral cryptographic secret in test/dev if `.env` is absent, and enforces strict startup checks in production.
2. **Database Transactions & ACID Integrity (`backend/db/database.js` & `dojoController.js`)**: Wrapped multi-table updates (`users` streak/solves + `squads` score/solves + `submissions` audit log) in explicit `BEGIN IMMEDIATE TRANSACTION` / `COMMIT` / `ROLLBACK` blocks with connection-safe serialized execution.
3. **Date-Based Daily Problem Dispatcher (`backend/services/dailyDispatcher.js`)**: Deterministic UTC date-seeded problem scheduler (`YYYY-MM-DD`) serving the active Daily Challenge (`/api/daily`) alongside full problem catalog filtering and paginated leaderboards (`/api/leaderboard?page=1&limit=10`).
4. **Full Python + JavaScript Sandboxed Execution (`src/modules/sandbox.js`)**: Upgraded `DojoSandbox` Web Worker to execute both JavaScript and Python (`solve(...)` AST/transpiler & Pyodide-ready worker runtime with strict 800ms timeout isolation) so Python test cases run live assertions instead of syntax-only checks.
5. **Hardened Security Headers & Structured Observability (`winston` + `helmet`)**: Added structured JSON/console logging via `winston` (`backend/utils/logger.js`), strict Content Security Policy without `'unsafe-inline'`, and granular HTTP error handling in `src/modules/api.js`.
6. **Comprehensive Backend + Frontend Automated Test Suite (`tests/run-tests.js`)**: End-to-end HTTP integration tests against live Express routes, SQLite transaction rollback tests, and headless DOM/UI + Web Worker + Levenshtein frontend component tests.

## Quick Start
```bash
cp .env.example .env
npm install
npm test
npm start
```
