(() => {
  "use strict";

  const state = window.DojoState;
  const api = window.DojoAPI;
  const ui = window.DojoUI;
  const utils = window.DojoUtils;
  const sandbox = window.DojoSandbox;

  document.getElementById("loginBtn").addEventListener("click", async () => {
    const handle = utils.sanitizeText(document.getElementById("usernameInput").value, 24);
    const password = document.getElementById("passcodeInput").value || "";
    if (!/^[a-zA-Z0-9_-]{3,24}$/.test(handle) || password.length < 4) {
      state.statusMessage = "Enter a valid handle (3-24 alphanumeric/_/- chars) and a 4+ character password.";
      ui.renderAll();
      return;
    }

    const res = await api.request("/auth/login", {
      method: "POST",
      body: JSON.stringify({ handle, password })
    });

    if (res.ok && res.data && res.data.token) {
      state.user = { handle: res.data.user.handle, token: res.data.token };
      state.streak = res.data.user.streak;
      state.solvedIds = res.data.user.solvedIds;
      state.failCount = res.data.user.failCount;
      state.activityDays = res.data.user.activityDays;
      state.statusMessage = `Authenticated as @${res.data.user.handle}`;
    } else if (res.networkDown) {
      state.user = { handle, token: "offline_local_token" };
      state.statusMessage = `Offline mode: signed in locally as @${handle}`;
    } else {
      state.statusMessage = `Sign-in rejected: ${res.error}`;
      ui.renderAll();
      return;
    }

    document.getElementById("passcodeInput").value = "";
    state.saveToLocal();
    window.bus.emit("auth:changed", state.user);
  });

  document.getElementById("logoutBtn").addEventListener("click", () => {
    state.user = null;
    state.statusMessage = "Signed out.";
    state.saveToLocal();
    ui.renderAll();
  });

  document.getElementById("tagFilter").addEventListener("change", () => {
    ui.populateProblemSelect();
    ui.renderAll();
  });

  document.getElementById("diffFilter").addEventListener("change", () => {
    ui.populateProblemSelect();
    ui.renderAll();
  });

  document.getElementById("langSelect").addEventListener("change", (e) => {
    state.selectedLanguage = e.target.value;
    ui.loadEditorStarterCode();
    document.getElementById("testResults").textContent = "";
  });

  document.getElementById("problemSelect").addEventListener("change", (e) => {
    state.selectedProblemId = e.target.value;
    ui.loadEditorStarterCode();
    document.getElementById("testResults").textContent = "";
    ui.renderAll();
  });

  document.getElementById("runTestsBtn").addEventListener("click", async () => {
    const lang = document.getElementById("langSelect").value;
    const code = document.getElementById("codeEditor").value;
    const prob = state.problems.find((p) => p.id === state.selectedProblemId);
    const out = document.getElementById("testResults");

    const res = await sandbox.runInWorker(code, prob.tests, lang);
    if (res.status !== "OK") {
      state.failCount += 1;
      out.textContent = `[${lang.toUpperCase()}] ${res.status}: ${res.error}`;
      state.saveToLocal();
      ui.renderAll();
      return;
    }

    const allPassed = res.results.every((r) => r.passed);
    if (!allPassed) state.failCount += 1;
    out.innerHTML = res.results
      .map(
        (r) =>
          `<div>[${lang.toUpperCase()}] Test #${r.index}: <strong>${r.passed ? "Accepted" : "Wrong Answer"}</strong> (got ${JSON.stringify(r.actual)}, expected ${JSON.stringify(r.expected)})</div>`
      )
      .join("");
    state.saveToLocal();
    ui.renderAll();
  });

  document.getElementById("submitSolBtn").addEventListener("click", async () => {
    if (!state.user) {
      state.statusMessage = "Please sign in with your handle and password before submitting.";
      ui.renderAll();
      return;
    }
    const lang = document.getElementById("langSelect").value;
    const code = document.getElementById("codeEditor").value;
    const prob = state.problems.find((p) => p.id === state.selectedProblemId);
    const res = await sandbox.runInWorker(code, prob.tests, lang);
    const out = document.getElementById("testResults");

    if (res.status !== "OK" || !res.results.every((r) => r.passed)) {
      state.failCount += 1;
      out.textContent = "Submission rejected: not all test cases passed.";
      state.saveToLocal();
      ui.renderAll();
      return;
    }

    const activeSquad = state.squads.find((s) => s.name === state.activeSquadName) || state.squads[0];
    const multiplier = state.sprintRunning ? 1.5 : 1;
    const earned = Math.round(prob.points * multiplier);

    const submitRes = await api.request("/submissions", {
      method: "POST",
      body: JSON.stringify({
        problemId: prob.id,
        language: lang,
        code,
        squadName: activeSquad.name,
        passed: true,
        points: earned
      })
    });

    if (submitRes.ok && submitRes.data) {
      state.streak = submitRes.data.user.streak;
      state.solvedIds = submitRes.data.user.solvedIds;
      state.failCount = submitRes.data.user.failCount;
      state.activityDays = submitRes.data.user.activityDays;
      state.squads = submitRes.data.squads;
      out.textContent =
        submitRes.data.awarded > 0
          ? `Accepted (${lang.toUpperCase()})! +${submitRes.data.awarded} pts committed atomically to ${activeSquad.name}.`
          : `Already solved "${prob.title}". Snippet updated without duplicate points.`;
    } else if (submitRes.networkDown) {
      activeSquad.lastSnippet = code;
      if (!state.solvedIds.includes(prob.id)) {
        state.solvedIds.push(prob.id);
        activeSquad.solves += 1;
        activeSquad.score += earned;
        out.textContent = `Accepted offline! +${earned} pts cached locally for ${activeSquad.name}.`;
      } else {
        out.textContent = `Already solved "${prob.title}".`;
      }
    } else {
      out.textContent = `Submission error: ${submitRes.error}`;
    }

    state.saveToLocal();
    ui.renderAll();
  });

  document.getElementById("squadForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = utils.sanitizeText(document.getElementById("squadNameInput").value, 32);
    const code = utils.sanitizeText(document.getElementById("squadCodeInput").value, 8).toUpperCase();
    if (!name || !/^[A-Z0-9]{4,8}$/.test(code)) {
      state.statusMessage = "Provide a squad name and a 4-8 character alphanumeric Team Access Code.";
      ui.renderAll();
      return;
    }

    const serverRes = await api.request("/squads", {
      method: "POST",
      body: JSON.stringify({ name, accessCode: code })
    });

    if (serverRes.ok && serverRes.data && serverRes.data.squads) {
      state.squads = serverRes.data.squads;
      state.activeSquadName = name;
      state.statusMessage = `Active squad set to ${name}.`;
    } else if (serverRes.networkDown) {
      let existing = state.squads.find((s) => s.name.toLowerCase() === name.toLowerCase());
      if (existing) {
        if (existing.accessCode !== code) {
          state.statusMessage = "Invalid Team Access Code for this squad.";
          ui.renderAll();
          return;
        }
        if (state.user && !existing.members.includes(state.user.handle) && existing.members.length < 4) {
          existing.members.push(state.user.handle);
        }
        state.activeSquadName = existing.name;
      } else {
        const members = state.user ? [state.user.handle] : ["captain_1"];
        state.squads.push({
          name,
          accessCode: code,
          members,
          solves: 0,
          streakBonus: 20,
          score: 20,
          lastSnippet: ""
        });
        state.activeSquadName = name;
      }
    } else {
      state.statusMessage = `Squad action failed: ${serverRes.error}`;
    }

    state.saveToLocal();
    ui.renderAll();
  });

  document.getElementById("addMemberBtn").addEventListener("click", async () => {
    const handle = utils.sanitizeText(document.getElementById("memberInput").value, 24);
    if (!/^[a-zA-Z0-9_-]{3,24}$/.test(handle)) {
      state.statusMessage = "Enter a valid member handle (3-24 chars).";
      ui.renderAll();
      return;
    }
    const activeSquad = state.squads.find((s) => s.name === state.activeSquadName) || state.squads[0];

    const res = await api.request("/squads/members", {
      method: "POST",
      body: JSON.stringify({ squadName: activeSquad.name, memberHandle: handle })
    });

    if (res.ok && res.data && res.data.squads) {
      state.squads = res.data.squads;
      state.statusMessage = `Added @${handle} to ${activeSquad.name}.`;
    } else if (res.networkDown) {
      if (activeSquad.members.length >= 4) {
        state.statusMessage = "Squad roster is full (max 4 members).";
      } else if (!activeSquad.members.includes(handle)) {
        activeSquad.members.push(handle);
      }
    } else {
      state.statusMessage = `Could not add member: ${res.error}`;
    }

    document.getElementById("memberInput").value = "";
    state.saveToLocal();
    ui.renderAll();
  });

  document.getElementById("prevPageBtn").addEventListener("click", () => {
    if (state.leaderboardPage > 1) {
      state.leaderboardPage -= 1;
      ui.renderAll();
    }
  });

  document.getElementById("nextPageBtn").addEventListener("click", () => {
    const totalPages = Math.max(1, Math.ceil(state.squads.length / state.leaderboardPageSize));
    if (state.leaderboardPage < totalPages) {
      state.leaderboardPage += 1;
      ui.renderAll();
    }
  });

  document.getElementById("toggleSprintBtn").addEventListener("click", () => {
    state.sprintRunning = !state.sprintRunning;
    ui.renderAll();
  });

  setInterval(() => {
    if (state.sprintRunning && state.sprintSeconds > 0) {
      state.sprintSeconds -= 1;
      ui.renderAll();
    }
  }, 1000);

  document.getElementById("checkPlagBtn").addEventListener("click", () => {
    const snippets = state.squads.filter((s) => s.lastSnippet);
    if (snippets.length < 2) {
      document.getElementById("plagiarismOutput").textContent = "Need at least 2 team submissions to compare similarity.";
      return;
    }
    const pairs = [];
    for (let i = 0; i < snippets.length; i++) {
      for (let j = i + 1; j < snippets.length; j++) {
        const sim = utils.similarityRatio(snippets[i].lastSnippet, snippets[j].lastSnippet);
        pairs.push(`${snippets[i].name} vs ${snippets[j].name}: ${sim}% similarity`);
      }
    }
    document.getElementById("plagiarismOutput").textContent = pairs.join(" | ");
  });

  window.bus.on("auth:changed", () => ui.renderAll());

  api.syncFromBackend().then(() => {
    ui.populateProblemSelect();
    ui.renderAll();
  });
})();
