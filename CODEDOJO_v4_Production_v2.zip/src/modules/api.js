(function (root) {
  const API_BASE = "http://localhost:3000/api";

  const DojoAPI = {
    async request(endpoint, options = {}) {
      const headers = { "Content-Type": "application/json", ...options.headers };
      const state = root.DojoState;
      if (state && state.user && state.user.token) {
        headers["Authorization"] = `Bearer ${state.user.token}`;
      }

      try {
        const res = await fetch(`${API_BASE}${endpoint}`, { ...options, headers });
        const payload = await res.json().catch(() => ({}));
        if (!res.ok) {
          return {
            ok: false,
            status: res.status,
            networkDown: false,
            error: payload.error || `HTTP ${res.status}`
          };
        }
        return { ok: true, status: res.status, data: payload };
      } catch (err) {
        return {
          ok: false,
          status: 0,
          networkDown: true,
          error: err.message || "Network unreachable"
        };
      }
    },

    async syncFromBackend() {
      const state = root.DojoState;
      state.loadFromLocal();

      const syncRes = await this.request("/sync");
      if (syncRes.ok && syncRes.data) {
        if (Array.isArray(syncRes.data.squads)) state.squads = syncRes.data.squads;
        if (Array.isArray(syncRes.data.problems) && syncRes.data.problems.length) {
          state.problems = syncRes.data.problems;
        }
        if (syncRes.data.daily && syncRes.data.daily.problem) {
          state.dailyMeta = {
            date: syncRes.data.daily.date,
            problemId: syncRes.data.daily.problem.id
          };
          state.selectedProblemId = syncRes.data.daily.problem.id;
        }
        state.statusMessage = "";
      } else if (syncRes.networkDown) {
        const idx = root.DojoUtils.computeDailyIndex(state.problems.length, new Date());
        state.dailyMeta = {
          date: new Date().toISOString().slice(0, 10),
          problemId: state.problems[idx].id
        };
        state.selectedProblemId = state.problems[idx].id;
        state.statusMessage = "Offline mode active: changes are saved locally until the API server is reachable.";
      }

      if (state.user && state.user.token) {
        const meRes = await this.request("/auth/me");
        if (meRes.ok && meRes.data && meRes.data.user) {
          state.streak = meRes.data.user.streak;
          state.solvedIds = meRes.data.user.solvedIds;
          state.failCount = meRes.data.user.failCount;
          state.activityDays = meRes.data.user.activityDays;
        } else if (meRes.status === 401 || meRes.status === 403) {
          state.user = null;
          state.statusMessage = "Session expired. Please sign in again.";
        }
      }

      state.saveToLocal();
      if (root.DojoUI) root.DojoUI.renderAll();
    }
  };

  root.DojoAPI = DojoAPI;
  if (typeof module !== "undefined" && module.exports) module.exports = DojoAPI;
})(typeof window !== "undefined" ? window : globalThis);
