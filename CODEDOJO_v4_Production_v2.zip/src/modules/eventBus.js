(function (root) {
  class EventBus {
    constructor() {
      this.listeners = new Map();
    }
    on(event, fn) {
      if (!this.listeners.has(event)) this.listeners.set(event, new Set());
      this.listeners.get(event).add(fn);
      return () => this.listeners.get(event)?.delete(fn);
    }
    emit(event, payload) {
      const set = this.listeners.get(event);
      if (!set) return;
      for (const fn of set) fn(payload);
    }
  }
  root.bus = new EventBus();
  if (typeof module !== "undefined" && module.exports) module.exports = EventBus;
})(typeof window !== "undefined" ? window : globalThis);
