(function (root) {
  /**
   * Lightweight Python-to-JS subset transpiler & runtime helper for sandboxed Worker execution.
   * Supports def solve(...), set(), len(), max(), min(), range(), list comprehensions,
   * slicing [::-1], [1:], if/elif/else, for/while loops, and boolean/None literals.
   */
  function transpilePythonToJS(pyCode) {
    const lines = String(pyCode || "").replace(/\r\n/g, "\n").split("\n");
    if (!lines.some((l) => /^\s*def\s+solve\s*\(/.test(l))) {
      throw new Error("Python SyntaxError: expected 'def solve(...):' entrypoint");
    }

    const jsLines = [
      "const True = true, False = false, None = null;",
      "const set = (it) => new Set(it || []);",
      "const len = (x) => (x && typeof x.length === 'number' ? x.length : (x && x.size) || 0);",
      "const max = (...a) => Math.max(...a);",
      "const min = (...a) => Math.min(...a);",
      "const str = (x) => String(x);",
      "Set.prototype.add_py = Set.prototype.add;",
      "function __pySlice(seq, start, end, step) {",
      "  const arr = typeof seq === 'string' ? seq.split('') : Array.from(seq);",
      "  if (step === -1 && start === null && end === null) {",
      "    const rev = arr.reverse();",
      "    return typeof seq === 'string' ? rev.join('') : rev;",
      "  }",
      "  const s = start === null ? 0 : start;",
      "  const e = end === null ? arr.length : end;",
      "  const sliced = arr.slice(s, e);",
      "  return typeof seq === 'string' ? sliced.join('') : sliced;",
      "}",
      "function __pyIn(item, container) {",
      "  if (container instanceof Set) return container.has(item);",
      "  if (Array.isArray(container) || typeof container === 'string') return container.includes(item);",
      "  return Object.prototype.hasOwnProperty.call(container, item);",
      "}"
    ];

    const indentStack = [0];

    function transformExpr(expr) {
      let e = expr.trim();
      // Handle join comprehension: ''.join(ch.lower() for ch in str(s) if ch.isalnum())
      e = e.replace(
        /(['"])(.*?)\1\.join\((.+?)\s+for\s+(\w+)\s+in\s+(.+?)\s+if\s+(.+?)\)/g,
        "Array.from($5).filter(($4) => $6).map(($4) => $3).join($1$2$1)"
      );
      e = e.replace(/(\w+)\.isalnum\(\)/g, "/^[a-z0-9]$/i.test($1)");
      e = e.replace(/(\w+)\.lower\(\)/g, "String($1).toLowerCase()");
      e = e.replace(/(\w+)\.add\(/g, "$1.add_py(");
      e = e.replace(/(\w+)\.append\(/g, "$1.push(");
      e = e.replace(/(\w+)\[::-1\]/g, "__pySlice($1, null, null, -1)");
      e = e.replace(/(\w+)\[(\d+):\]/g, "__pySlice($1, $2, null, 1)");
      e = e.replace(/\bnot\s+([a-zA-Z0-9_().]+)/g, "!($1)");
      e = e.replace(/(.+?)\s+not\s+in\s+(.+)/g, "!__pyIn($1, $2)");
      e = e.replace(/(.+?)\s+in\s+(.+)/g, "__pyIn($1, $2)");
      e = e.replace(/\band\b/g, "&&").replace(/\bor\b/g, "||");
      return e;
    }

    for (const rawLine of lines) {
      const strippedComment = rawLine.replace(/#.*$/, "");
      if (!strippedComment.trim()) continue;

      const indent = strippedComment.match(/^\s*/)[0].length;
      const trimmed = strippedComment.trim();

      while (indent < indentStack[indentStack.length - 1]) {
        indentStack.pop();
        jsLines.push("}".padStart(indentStack[indentStack.length - 1] + 1, " "));
      }

      if (trimmed.startsWith("def ")) {
        const sig = trimmed.replace(/^def\s+/, "function ").replace(/:$/, " {");
        jsLines.push(sig);
        indentStack.push(indent + 4);
      } else if (trimmed.startsWith("if ") && trimmed.endsWith(":")) {
        const cond = transformExpr(trimmed.slice(3, -1));
        jsLines.push(`if (${cond}) {`);
        indentStack.push(indent + 4);
      } else if (trimmed.startsWith("elif ") && trimmed.endsWith(":")) {
        const cond = transformExpr(trimmed.slice(5, -1));
        jsLines.push(`else if (${cond}) {`);
        indentStack.push(indent + 4);
      } else if (trimmed === "else:") {
        jsLines.push("else {");
        indentStack.push(indent + 4);
      } else if (trimmed.startsWith("for ") && trimmed.endsWith(":")) {
        const m = trimmed.slice(4, -1).match(/^(\w+)\s+in\s+(.+)$/);
        if (!m) throw new Error(`Unsupported Python for-loop: ${trimmed}`);
        const iter = transformExpr(m[2]);
        jsLines.push(`for (const ${m[1]} of ${iter}) {`);
        indentStack.push(indent + 4);
      } else if (trimmed.startsWith("while ") && trimmed.endsWith(":")) {
        const cond = transformExpr(trimmed.slice(6, -1));
        jsLines.push(`while (${cond}) {`);
        indentStack.push(indent + 4);
      } else if (trimmed.startsWith("return ")) {
        jsLines.push(`return ${transformExpr(trimmed.slice(7))};`);
      } else {
        // Chained assignment e.g. cur = best = nums[0]
        const chainMatch = trimmed.match(/^(\w+)\s*=\s*(\w+)\s*=\s*(.+)$/);
        if (chainMatch) {
          const rhs = transformExpr(chainMatch[3]);
          jsLines.push(`let ${chainMatch[1]} = ${rhs}; let ${chainMatch[2]} = ${chainMatch[1]};`);
        } else if (/^\w+\s*=/.test(trimmed) && !/==|!=|<=|>=/.test(trimmed)) {
          const eqIdx = trimmed.indexOf("=");
          const lhs = trimmed.slice(0, eqIdx).trim();
          const rhs = transformExpr(trimmed.slice(eqIdx + 1));
          jsLines.push(`var ${lhs} = ${rhs};`);
        } else {
          jsLines.push(`${transformExpr(trimmed)};`);
        }
      }
    }

    while (indentStack.length > 1) {
      indentStack.pop();
      jsLines.push("}");
    }

    return jsLines.join("\n");
  }

  function executeDirect(code, tests, language = "javascript") {
    try {
      const executableCode = language === "python" ? transpilePythonToJS(code) : code;
      const fn = new Function(
        '"use strict"; ' +
          executableCode +
          '\nif (typeof solve !== "function") throw new Error("Define function solve(...)"); return solve;'
      );
      const solveFn = fn();
      const results = tests.map((t, idx) => {
        const actual = solveFn(...JSON.parse(JSON.stringify(t.args)));
        const passed = JSON.stringify(actual) === JSON.stringify(t.expected);
        return { index: idx + 1, passed, actual, expected: t.expected };
      });
      return { status: "OK", language, results };
    } catch (err) {
      return { status: "ERR", language, error: err && err.message ? err.message : "Runtime Error" };
    }
  }

  const DojoSandbox = {
    transpilePythonToJS,
    executeDirect,

    runInWorker(code, tests, language = "javascript", timeoutMs = 800) {
      if (typeof Worker === "undefined" || typeof Blob === "undefined") {
        return Promise.resolve(executeDirect(code, tests, language));
      }

      let executableCode;
      try {
        executableCode = language === "python" ? transpilePythonToJS(code) : code;
      } catch (err) {
        return Promise.resolve({ status: "ERR", language, error: err.message });
      }

      return new Promise((resolve) => {
        const workerBlob = new Blob(
          [
            `
          self.onmessage = function(e) {
            const { code, tests, language } = e.data;
            try {
              const fn = new Function('"use strict"; ' + code + '\nif (typeof solve !== "function") throw new Error("Define function solve(...)"); return solve;');
              const solveFn = fn();
              const results = tests.map((t, idx) => {
                const actual = solveFn(...JSON.parse(JSON.stringify(t.args)));
                const passed = JSON.stringify(actual) === JSON.stringify(t.expected);
                return { index: idx + 1, passed, actual, expected: t.expected };
              });
              self.postMessage({ status: "OK", language, results });
            } catch (err) {
              self.postMessage({ status: "ERR", language, error: err && err.message ? err.message : "Runtime Error" });
            }
          };
        `
          ],
          { type: "application/javascript" }
        );

        const url = URL.createObjectURL(workerBlob);
        const worker = new Worker(url);
        let settled = false;

        const timer = setTimeout(() => {
          if (!settled) {
            settled = true;
            worker.terminate();
            URL.revokeObjectURL(url);
            resolve({ status: "TLE", language, error: `Time Limit Exceeded (>${timeoutMs}ms)` });
          }
        }, timeoutMs);

        worker.onmessage = (ev) => {
          if (!settled) {
            settled = true;
            clearTimeout(timer);
            worker.terminate();
            URL.revokeObjectURL(url);
            resolve(ev.data);
          }
        };

        worker.onerror = () => {
          if (!settled) {
            settled = true;
            clearTimeout(timer);
            worker.terminate();
            URL.revokeObjectURL(url);
            resolve({ status: "ERR", language, error: "Sandbox execution error" });
          }
        };

        worker.postMessage({ code: executableCode, tests, language });
      });
    }
  };

  root.DojoSandbox = DojoSandbox;
  if (typeof module !== "undefined" && module.exports) module.exports = DojoSandbox;
})(typeof window !== "undefined" ? window : globalThis);
