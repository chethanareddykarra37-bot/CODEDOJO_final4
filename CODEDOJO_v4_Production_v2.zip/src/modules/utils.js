(function (root) {
  const DojoUtils = {
    sanitizeText(input, maxLen = 120) {
      return String(input ?? "")
        .replace(/[<>&"'`]/g, "")
        .trim()
        .slice(0, maxLen);
    },

    levenshteinDistance(a, b) {
      const s1 = String(a || "").trim();
      const s2 = String(b || "").trim();
      const m = s1.length;
      const n = s2.length;
      if (m === 0) return n;
      if (n === 0) return m;
      const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
      for (let i = 0; i <= m; i++) dp[i][0] = i;
      for (let j = 0; j <= n; j++) dp[0][j] = j;
      for (let i = 1; i <= m; i++) {
        for (let j = 1; j <= n; j++) {
          const cost = s1[i - 1] === s2[j - 1] ? 0 : 1;
          dp[i][j] = Math.min(
            dp[i - 1][j] + 1,
            dp[i][j - 1] + 1,
            dp[i - 1][j - 1] + cost
          );
        }
      }
      return dp[m][n];
    },

    similarityRatio(a, b) {
      const maxLen = Math.max(String(a || "").length, String(b || "").length);
      if (maxLen === 0) return 100;
      const dist = this.levenshteinDistance(a, b);
      return Math.round(((maxLen - dist) / maxLen) * 100);
    },

    computeDailyIndex(problemsCount, dateObj = new Date()) {
      if (!problemsCount) return 0;
      const epochDays = Math.floor(
        Date.UTC(dateObj.getUTCFullYear(), dateObj.getUTCMonth(), dateObj.getUTCDate()) / 86400000
      );
      return Math.abs(epochDays) % problemsCount;
    }
  };

  root.DojoUtils = DojoUtils;
  if (typeof module !== "undefined" && module.exports) module.exports = DojoUtils;
})(typeof window !== "undefined" ? window : globalThis);
