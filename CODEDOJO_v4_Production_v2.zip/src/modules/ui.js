(function (root) {
  const DojoUI = {
    renderAll() {
      const state = root.DojoState;
      const sanitize = root.DojoUtils.sanitizeText;

      const banner = document.getElementById("statusBanner");
      if (banner) {
        if (state.statusMessage) {
          banner.textContent = state.statusMessage;
          banner.classList.remove("hidden");
        } else {
          banner.classList.add("hidden");
        }
      }

      document.getElementById("streakCount").textContent = `${state.streak} days`;
      document.getElementById("solvedCount").textContent = `${state.solvedIds.length}`;
      document.getElementById("failCount").textContent = `${state.failCount}`;

      const mins = String(Math.floor(state.sprintSeconds / 60)).padStart(2, "0");
      const secs = String(state.sprintSeconds % 60).padStart(2, "0");
      document.getElementById("sprintTimer").textContent = `${mins}:${secs}`;

      const badge = document.getElementById("sessionBadge");
      const loginBtn = document.getElementById("loginBtn");
      const logoutBtn = document.getElementById("logoutBtn");
      const usernameInput = document.getElementById("usernameInput");
      const passcodeInput = document.getElementById("passcodeInput");

      if (state.user) {
        badge.textContent = `Signed in: @${state.user.handle}`;
        badge.classList.remove("hidden");
        loginBtn.classList.add("hidden");
        logoutBtn.classList.remove("hidden");
        usernameInput.classList.add("hidden");
        passcodeInput.classList.add("hidden");
      } else {
        badge.classList.add("hidden");
        loginBtn.classList.remove("hidden");
        logoutBtn.classList.remove("hidden");
        logoutBtn.classList.add("hidden");
        usernameInput.classList.remove("hidden");
        passcodeInput.classList.remove("hidden");
      }

      const dailyBadge = document.getElementById("dailyDateBadge");
      if (dailyBadge && state.dailyMeta) {
        dailyBadge.textContent = `UTC Daily Drop (${state.dailyMeta.date}) • Featured: ${state.dailyMeta.problemId.toUpperCase()}`;
      }

      const prob = state.problems.find((p) => p.id === state.selectedProblemId) || state.problems[0];
      if (prob) {
        const isDaily = state.dailyMeta && prob.id === state.dailyMeta.problemId;
        document.getElementById("problemDetails").innerHTML = `
          <div>
            <strong>${sanitize(prob.title)}</strong>
            <span class="badge">${sanitize(prob.difficulty)} • ${prob.points} pts</span>
            ${isDaily ? '<span class="badge">TODAY\'S DAILY</span>' : ""}
          </div>
          <p>${sanitize(prob.statement, 320)}</p>
          <p><strong>Sample:</strong> <code>${sanitize(prob.sampleInput)}</code> → <code>${sanitize(prob.sampleOutput)}</code></p>
          <p><strong>Tags:</strong> ${prob.tags.map((t) => sanitize(t)).join(", ")}</p>
        `;
      }

      const hintBox = document.getElementById("hintBox");
      if (state.failCount >= 3 && prob) {
        hintBox.textContent = `AI Hint (unlocked after 3 failed runs): ${prob.hint}`;
        hintBox.classList.remove("hidden");
      } else {
        hintBox.classList.add("hidden");
      }

      const activeSquad = state.squads.find((s) => s.name === state.activeSquadName) || state.squads[0];
      if (activeSquad) {
        document.getElementById("squadDisplay").innerHTML = `
          <div><strong>Squad:</strong> ${sanitize(activeSquad.name)} <span class="badge">Code: ${sanitize(activeSquad.accessCode)}</span></div>
          <div><strong>Members (${activeSquad.members.length}/4):</strong> ${activeSquad.members.map((m) => sanitize(m)).join(", ")}</div>
        `;
      }

      const sorted = [...state.squads].sort((a, b) => b.score - a.score);
      const totalPages = Math.max(1, Math.ceil(sorted.length / state.leaderboardPageSize));
      if (state.leaderboardPage > totalPages) state.leaderboardPage = totalPages;
      const startIdx = (state.leaderboardPage - 1) * state.leaderboardPageSize;
      const pageSlice = sorted.slice(startIdx, startIdx + state.leaderboardPageSize);

      document.getElementById("leaderboardBody").innerHTML = pageSlice
        .map(
          (sq, idx) => `
        <tr>
          <td>#${startIdx + idx + 1}</td>
          <td>${sanitize(sq.name)}</td>
          <td>${sq.solves}</td>
          <td>+${sq.streakBonus}</td>
          <td><strong>${sq.score}</strong></td>
        </tr>
      `
        )
        .join("");

      const pageIndicator = document.getElementById("pageIndicator");
      if (pageIndicator) {
        pageIndicator.textContent = `Page ${state.leaderboardPage} of ${totalPages}`;
      }

      const heatmap = document.getElementById("heatmapGrid");
      heatmap.innerHTML = state.activityDays
        .map((lvl) => `<div class="heat-cell heat-${Math.min(4, Math.max(0, lvl))}" title="Activity level ${lvl}"></div>`)
        .join("");
    },

    populateProblemSelect() {
      const state = root.DojoState;
      const tag = document.getElementById("tagFilter").value;
      const diff = document.getElementById("diffFilter").value;
      const filtered = state.problems.filter((p) => {
        const tagOk = tag === "ALL" || p.tags.includes(tag);
        const diffOk = diff === "ALL" || p.difficulty === diff;
        return tagOk && diffOk;
      });
      const list = filtered.length ? filtered : state.problems;
      const sel = document.getElementById("problemSelect");
      sel.innerHTML = list
        .map((p) => `<option value="${p.id}">${root.DojoUtils.sanitizeText(p.title)} (${p.difficulty})</option>`)
        .join("");
      if (!list.some((p) => p.id === state.selectedProblemId)) {
        state.selectedProblemId = list[0].id;
      }
      sel.value = state.selectedProblemId;
      this.loadEditorStarterCode();
    },

    loadEditorStarterCode() {
      const state = root.DojoState;
      const prob = state.problems.find((p) => p.id === state.selectedProblemId);
      if (!prob) return;
      const lang = document.getElementById("langSelect").value;
      document.getElementById("codeEditor").value =
        lang === "python" && prob.pythonStarterCode ? prob.pythonStarterCode : prob.starterCode;
    }
  };

  root.DojoUI = DojoUI;
  if (typeof module !== "undefined" && module.exports) module.exports = DojoUI;
})(typeof window !== "undefined" ? window : globalThis);
