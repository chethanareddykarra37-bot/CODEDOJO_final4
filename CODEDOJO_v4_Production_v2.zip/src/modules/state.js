(function (root) {
  const DEFAULT_PROBLEMS = [
    {
      id: "p1",
      title: "Two Sum Variant",
      difficulty: "Easy",
      tags: ["Arrays", "Hash Maps"],
      points: 100,
      statement: "Given an array of integers and a target sum, return true if any two distinct elements add up to target.",
      sampleInput: "[2, 7, 11, 15], target = 9",
      sampleOutput: "true",
      hint: "Think about storing complements in a Set or Map as you scan once through the array.",
      starterCode: "function solve(nums, target) {\n  const seen = new Set();\n  for (const n of nums) {\n    if (seen.has(target - n)) return true;\n    seen.add(n);\n  }\n  return false;\n}",
      pythonStarterCode: "def solve(nums, target):\n    seen = set()\n    for n in nums:\n        if (target - n) in seen:\n            return True\n        seen.add(n)\n    return False",
      tests: [
        { args: [[2, 7, 11, 15], 9], expected: true },
        { args: [[3, 2, 4], 6], "expected": true },
        { args: [[1, 2, 3], 10], "expected": false },
        { args: [[-5, 10, 3], 5], "expected": true }
      ]
    },
    {
      id: "p2",
      title: "Valid Palindrome Stream",
      difficulty: "Easy",
      tags: ["Two Pointers", "Strings"],
      points: 120,
      statement: "Return true if the alphanumeric characters of s form a palindrome (case-insensitive).",
      sampleInput: '"A man, a plan, a canal: Panama"',
      sampleOutput: "true",
      hint: "Use two pointers from start and end, skipping non-alphanumeric characters.",
      starterCode: "function solve(s) {\n  const clean = String(s).toLowerCase().replace(/[^a-z0-9]/g, '');\n  let l = 0, r = clean.length - 1;\n  while (l < r) {\n    if (clean[l++] !== clean[r--]) return false;\n  }\n  return true;\n}",
      pythonStarterCode: "def solve(s):\n    clean = ''.join(ch.lower() for ch in str(s) if ch.isalnum())\n    return clean == clean[::-1]",
      tests: [
        { args: ["A man, a plan, a canal: Panama"], expected: true },
        { args: ["race a car"], expected: false },
        { args: [""], expected: true }
      ]
    },
    {
      id: "p3",
      title: "Max Subarray Sprint",
      difficulty: "Medium",
      tags: ["Arrays", "Dynamic Programming"],
      points: 180,
      statement: "Find the maximum sum of a contiguous non-empty subarray.",
      sampleInput: "[-2, 1, -3, 4, -1, 2, 1, -5, 4]",
      sampleOutput: "6",
      hint: "At each element, decide whether to extend the current subarray or start fresh at the current value.",
      starterCode: "function solve(nums) {\n  let cur = nums[0], best = nums[0];\n  for (let i = 1; i < nums.length; i++) {\n    cur = Math.max(nums[i], cur + nums[i]);\n    best = Math.max(best, cur);\n  }\n  return best;\n}",
      pythonStarterCode: "def solve(nums):\n    cur = best = nums[0]\n    for x in nums[1:]:\n        cur = max(x, cur + x)\n        best = max(best, cur)\n    return best",
      tests: [
        { args: [[-2, 1, -3, 4, -1, 2, 1, -5, 4]], expected: 6 },
        { args: [[5]], expected: 5 },
        { args: [[-4, -2, -9]], expected: -2 }
      ]
    }
  ];

  const DojoState = {
    user: null,
    problems: DEFAULT_PROBLEMS,
    dailyMeta: { date: new Date().toISOString().slice(0, 10), problemId: "p1" },
    selectedProblemId: "p1",
    selectedLanguage: "javascript",
    streak: 1,
    solvedIds: [],
    failCount: 0,
    activityDays: [0, 1, 2, 1, 3, 2, 4, 1, 2, 0, 3, 4, 2, 1],
    squads: [
      {
        name: "Binary Beasts",
        accessCode: "DOJO2026",
        members: ["aarav_cs", "diya_dev", "rohan_algo"],
        solves: 4,
        streakBonus: 60,
        score: 460,
        lastSnippet: "function solve(nums, target) { return true; }"
      },
      {
        name: "Stack Overflowers",
        accessCode: "STACK99",
        members: ["meera_py", "kabir_ts"],
        solves: 3,
        streakBonus: 40,
        score: 340,
        lastSnippet: "function solve(nums, target) { return false; }"
      }
    ],
    leaderboardPage: 1,
    leaderboardPageSize: 5,
    activeSquadName: "Binary Beasts",
    sprintSeconds: 3600,
    sprintRunning: false,
    statusMessage: "",

    saveToLocal() {
      try {
        if (typeof localStorage === "undefined") return;
        localStorage.setItem("codedojo_state_v4", JSON.stringify({
          user: this.user,
          streak: this.streak,
          solvedIds: this.solvedIds,
          failCount: this.failCount,
          activityDays: this.activityDays,
          squads: this.squads,
          activeSquadName: this.activeSquadName
        }));
      } catch (_e) {
        // Storage quota or private mode ignored
      }
    },

    loadFromLocal() {
      try {
        if (typeof localStorage === "undefined") return;
        const saved = localStorage.getItem("codedojo_state_v4");
        if (saved) {
          const parsed = JSON.parse(saved);
          if (parsed.user) this.user = parsed.user;
          if (Array.isArray(parsed.solvedIds)) this.solvedIds = parsed.solvedIds;
          if (typeof parsed.streak === "number") this.streak = parsed.streak;
          if (typeof parsed.failCount === "number") this.failCount = parsed.failCount;
          if (Array.isArray(parsed.activityDays)) this.activityDays = parsed.activityDays;
          if (Array.isArray(parsed.squads) && parsed.squads.length > 0) this.squads = parsed.squads;
          if (parsed.activeSquadName) this.activeSquadName = parsed.activeSquadName;
        }
      } catch (_e) {
        // Ignore malformed local state
      }
    }
  };

  root.DojoState = DojoState;
  if (typeof module !== "undefined" && module.exports) module.exports = DojoState;
})(typeof window !== "undefined" ? window : globalThis);
