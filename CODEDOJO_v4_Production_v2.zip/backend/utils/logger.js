const winston = require("winston");
const { NODE_ENV } = require("../config/env");

const logger = winston.createLogger({
  level: NODE_ENV === "test" ? "error" : "info",
  format: winston.format.combine(
    winston.format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
    winston.format.errors({ stack: true }),
    winston.format.printf(({ timestamp, level, message, ...meta }) => {
      const metaStr = Object.keys(meta).length ? ` ${JSON.stringify(meta)}` : "";
      return `[${timestamp}] ${level.toUpperCase()}: ${message}${metaStr}`;
    })
  ),
  transports: [new winston.transports.Console()]
});

module.exports = logger;
