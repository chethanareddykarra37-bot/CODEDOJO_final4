const Joi = require("joi");

const loginSchema = Joi.object({
  handle: Joi.string().pattern(/^[a-zA-Z0-9_-]{3,24}$/).required(),
  password: Joi.string().min(4).max(64).required()
});

const squadSchema = Joi.object({
  name: Joi.string().trim().min(2).max(32).required(),
  accessCode: Joi.string().alphanum().min(4).max(8).uppercase().required()
});

const squadMemberSchema = Joi.object({
  squadName: Joi.string().trim().min(2).max(32).required(),
  memberHandle: Joi.string().pattern(/^[a-zA-Z0-9_-]{3,24}$/).required()
});

const submissionSchema = Joi.object({
  problemId: Joi.string().min(1).max(32).required(),
  language: Joi.string().valid("javascript", "python").default("javascript"),
  code: Joi.string().min(1).max(16000).required(),
  squadName: Joi.string().trim().min(2).max(32).required(),
  passed: Joi.boolean().required(),
  points: Joi.number().integer().min(0).max(1000).optional()
});

function validateBody(schema) {
  return (req, res, next) => {
    const { error, value } = schema.validate(req.body, { stripUnknown: true });
    if (error) {
      return res.status(400).json({ error: "Validation Error: " + error.details[0].message });
    }
    req.body = value;
    next();
  };
}

module.exports = {
  validateLogin: validateBody(loginSchema),
  validateSquad: validateBody(squadSchema),
  validateSquadMember: validateBody(squadMemberSchema),
  validateSubmission: validateBody(submissionSchema)
};
