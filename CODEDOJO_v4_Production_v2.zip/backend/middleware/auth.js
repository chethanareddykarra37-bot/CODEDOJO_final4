const jwt = require("jsonwebtoken");
const { JWT_SECRET } = require("../config/env");

function authenticateJWT(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Access Denied: Missing or malformed authorization token" });
  }

  const token = authHeader.split(" ")[1];
  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      if (err.name === "TokenExpiredError") {
        return res.status(401).json({ error: "Session Expired: Please log in again." });
      }
      return res.status(403).json({ error: "Forbidden: Invalid JWT Token" });
    }
    req.user = decoded;
    next();
  });
}

function optionalJWT(req, _res, next) {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    const token = authHeader.split(" ")[1];
    try {
      req.user = jwt.verify(token, JWT_SECRET);
    } catch (_e) {
      // Ignore invalid optional token
    }
  }
  next();
}

module.exports = { authenticateJWT, optionalJWT };
