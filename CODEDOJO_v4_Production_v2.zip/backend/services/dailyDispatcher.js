const fs = require("fs");
const path = require("path");

const problemsPath = path.resolve(__dirname, "../../data/problems.json");

function loadProblems() {
  const raw = fs.readFileSync(problemsPath, "utf-8");
  return JSON.parse(raw);
}

/**
 * Deterministic UTC date-based daily problem dispatcher.
 * Computes day index since Unix epoch so every calendar day maps to a scheduled problem.
 */
function getDailyProblem(dateObj = new Date()) {
  const problems = loadProblems();
  if (!problems.length) return null;

  const utcDateStr = dateObj.toISOString().slice(0, 10);
  const epochDays = Math.floor(Date.UTC(
    dateObj.getUTCFullYear(),
    dateObj.getUTCMonth(),
    dateObj.getUTCDate()
  ) / 86400000);

  const index = Math.abs(epochDays) % problems.length;
  const nextMidnightUTC = new Date(Date.UTC(
    dateObj.getUTCFullYear(),
    dateObj.getUTCMonth(),
    dateObj.getUTCDate() + 1,
    0, 0, 0
  )).toISOString();

  return {
    date: utcDateStr,
    rotationIndex: index + 1,
    totalCatalog: problems.length,
    resetsAtUTC: nextMidnightUTC,
    problem: problems[index]
  };
}

module.exports = {
  loadProblems,
  getDailyProblem
};
