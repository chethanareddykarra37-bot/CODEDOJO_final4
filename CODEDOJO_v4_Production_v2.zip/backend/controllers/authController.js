const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../db/database");
const { JWT_SECRET } = require("../config/env");
const logger = require("../utils/logger");

exports.loginOrRegister = async (req, res, next) => {
  try {
    await db.ready;
    const { handle, password } = req.body;
    const user = await db.get("SELECT * FROM users WHERE handle = ?", [handle]);

    if (!user) {
      const salt = await bcrypt.genSalt(10);
      const passwordHash = await bcrypt.hash(password, salt);
      const defaultSolved = JSON.stringify([]);
      const defaultActivity = JSON.stringify([0, 0, 1, 1, 2, 1, 2, 1, 3, 2, 4, 1, 2, 1]);

      const inserted = await db.run(
        "INSERT INTO users (handle, password_hash, streak, solved_ids, fail_count, activity_days) VALUES (?, ?, ?, ?, ?, ?)",
        [handle, passwordHash, 1, defaultSolved, 0, defaultActivity]
      );

      const token = jwt.sign({ id: inserted.lastID, handle }, JWT_SECRET, { expiresIn: "24h" });
      logger.info("New user registered", { handle });
      return res.status(201).json({
        token,
        user: {
          handle,
          streak: 1,
          solvedIds: [],
          failCount: 0,
          activityDays: JSON.parse(defaultActivity)
        }
      });
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      logger.warn("Failed login attempt", { handle });
      return res.status(401).json({ error: "Invalid password credentials." });
    }

    const token = jwt.sign({ id: user.id, handle: user.handle }, JWT_SECRET, { expiresIn: "24h" });
    logger.info("User signed in", { handle });
    return res.json({
      token,
      user: {
        handle: user.handle,
        streak: user.streak,
        solvedIds: JSON.parse(user.solved_ids || "[]"),
        failCount: user.fail_count,
        activityDays: JSON.parse(user.activity_days || "[]")
      }
    });
  } catch (err) {
    next(err);
  }
};

exports.getMe = async (req, res, next) => {
  try {
    await db.ready;
    const user = await db.get("SELECT * FROM users WHERE handle = ?", [req.user.handle]);
    if (!user) return res.status(404).json({ error: "User not found" });

    return res.json({
      user: {
        handle: user.handle,
        streak: user.streak,
        solvedIds: JSON.parse(user.solved_ids || "[]"),
        failCount: user.fail_count,
        activityDays: JSON.parse(user.activity_days || "[]")
      }
    });
  } catch (err) {
    next(err);
  }
};
