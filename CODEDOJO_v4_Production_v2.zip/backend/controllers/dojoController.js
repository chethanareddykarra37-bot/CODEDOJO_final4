const db = require("../db/database");
const { loadProblems, getDailyProblem } = require("../services/dailyDispatcher");
const logger = require("../utils/logger");

function formatSquadRow(r) {
  return {
    name: r.name,
    accessCode: r.accessCode,
    members: JSON.parse(r.members || "[]"),
    solves: r.solves,
    streakBonus: r.streakBonus,
    score: r.score,
    lastSnippet: r.lastSnippet
  };
}

exports.getDailyChallenge = (req, res) => {
  const customDate = req.query.date ? new Date(req.query.date) : new Date();
  if (Number.isNaN(customDate.getTime())) {
    return res.status(400).json({ error: "Invalid ISO date query parameter." });
  }
  const daily = getDailyProblem(customDate);
  res.json(daily);
};

exports.getLeaderboard = async (req, res, next) => {
  try {
    await db.ready;
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit, 10) || 10));
    const offset = (page - 1) * limit;

    const totalRow = await db.get("SELECT COUNT(*) AS total FROM squads");
    const rows = await db.all(
      `SELECT name, access_code AS accessCode, members, solves, streak_bonus AS streakBonus, score, last_snippet AS lastSnippet
       FROM squads ORDER BY score DESC, solves DESC LIMIT ? OFFSET ?`,
      [limit, offset]
    );

    res.json({
      page,
      limit,
      total: totalRow.total,
      totalPages: Math.ceil(totalRow.total / limit),
      squads: rows.map(formatSquadRow)
    });
  } catch (err) {
    next(err);
  }
};

exports.syncData = async (req, res, next) => {
  try {
    await db.ready;
    const rows = await db.all(
      "SELECT name, access_code AS accessCode, members, solves, streak_bonus AS streakBonus, score, last_snippet AS lastSnippet FROM squads ORDER BY score DESC"
    );
    const problems = loadProblems();
    const daily = getDailyProblem(new Date());

    res.json({
      squads: rows.map(formatSquadRow),
      problems,
      daily
    });
  } catch (err) {
    next(err);
  }
};

exports.manageSquad = async (req, res, next) => {
  try {
    await db.ready;
    const { name, accessCode } = req.body;
    const actorHandle = req.user ? req.user.handle : "captain_1";

    const result = await db.withTransaction(async (tx) => {
      const squad = await tx.get("SELECT * FROM squads WHERE LOWER(name) = LOWER(?)", [name]);
      if (squad) {
        if (squad.access_code !== accessCode) {
          const err = new Error("Incorrect Team Access Code.");
          err.status = 403;
          throw err;
        }
        const members = JSON.parse(squad.members || "[]");
        if (!members.includes(actorHandle) && members.length < 4) {
          members.push(actorHandle);
          await tx.run("UPDATE squads SET members = ? WHERE id = ?", [JSON.stringify(members), squad.id]);
        }
      } else {
        await tx.run(
          "INSERT INTO squads (name, access_code, members, solves, streak_bonus, score, last_snippet) VALUES (?, ?, ?, ?, ?, ?, ?)",
          [name, accessCode, JSON.stringify([actorHandle]), 0, 20, 20, ""]
        );
      }

      const rows = await tx.all(
        "SELECT name, access_code AS accessCode, members, solves, streak_bonus AS streakBonus, score, last_snippet AS lastSnippet FROM squads ORDER BY score DESC"
      );
      return rows.map(formatSquadRow);
    });

    logger.info("Squad created or joined", { squad: name, actor: actorHandle });
    res.json({ squads: result });
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.message });
    next(err);
  }
};

exports.addSquadMember = async (req, res, next) => {
  try {
    await db.ready;
    const { squadName, memberHandle } = req.body;

    const squads = await db.withTransaction(async (tx) => {
      const squad = await tx.get("SELECT * FROM squads WHERE LOWER(name) = LOWER(?)", [squadName]);
      if (!squad) {
        const err = new Error("Squad not found.");
        err.status = 404;
        throw err;
      }
      const members = JSON.parse(squad.members || "[]");
      if (members.length >= 4 && !members.includes(memberHandle)) {
        const err = new Error("Squad roster is full (max 4 members).");
        err.status = 400;
        throw err;
      }
      if (!members.includes(memberHandle)) {
        members.push(memberHandle);
        await tx.run("UPDATE squads SET members = ? WHERE id = ?", [JSON.stringify(members), squad.id]);
      }
      const rows = await tx.all(
        "SELECT name, access_code AS accessCode, members, solves, streak_bonus AS streakBonus, score, last_snippet AS lastSnippet FROM squads ORDER BY score DESC"
      );
      return rows.map(formatSquadRow);
    });

    res.json({ squads });
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.message });
    next(err);
  }
};

exports.submitSolution = async (req, res, next) => {
  try {
    await db.ready;
    const { problemId, language, code, squadName, passed, points } = req.body;
    const handle = req.user.handle;
    const todayUTC = new Date().toISOString().slice(0, 10);

    const payload = await db.withTransaction(async (tx) => {
      const user = await tx.get("SELECT * FROM users WHERE handle = ?", [handle]);
      if (!user) {
        const err = new Error("User not found");
        err.status = 404;
        throw err;
      }

      const squad = await tx.get("SELECT * FROM squads WHERE name = ?", [squadName]);
      if (!squad) {
        const err = new Error(`Target squad '${squadName}' does not exist.`);
        err.status = 404;
        throw err;
      }

      const solvedIds = JSON.parse(user.solved_ids || "[]");
      const activityDays = JSON.parse(user.activity_days || "[0,0,0,0,0,0,0,0,0,0,0,0,0,0]");
      let newStreak = user.streak;
      let newFailCount = user.fail_count;
      let awarded = 0;

      if (passed) {
        if (!solvedIds.includes(problemId)) {
          solvedIds.push(problemId);
          if (user.last_solved_date !== todayUTC) {
            newStreak = user.streak + 1;
          }
          awarded = points || 100;
          activityDays[activityDays.length - 1] = Math.min(4, (activityDays[activityDays.length - 1] || 0) + 2);

          await tx.run(
            "UPDATE users SET solved_ids = ?, streak = ?, last_solved_date = ?, activity_days = ? WHERE handle = ?",
            [JSON.stringify(solvedIds), newStreak, todayUTC, JSON.stringify(activityDays), handle]
          );

          await tx.run(
            "UPDATE squads SET solves = solves + 1, score = score + ?, last_snippet = ? WHERE id = ?",
            [awarded, code, squad.id]
          );
        } else {
          await tx.run("UPDATE squads SET last_snippet = ? WHERE id = ?", [code, squad.id]);
        }
      } else {
        newFailCount += 1;
        await tx.run("UPDATE users SET fail_count = ? WHERE handle = ?", [newFailCount, handle]);
      }

      await tx.run(
        "INSERT INTO submissions (user_handle, problem_id, language, passed, points_awarded, code) VALUES (?, ?, ?, ?, ?, ?)",
        [handle, problemId, language || "javascript", passed ? 1 : 0, awarded, code]
      );

      const rows = await tx.all(
        "SELECT name, access_code AS accessCode, members, solves, streak_bonus AS streakBonus, score, last_snippet AS lastSnippet FROM squads ORDER BY score DESC"
      );

      return {
        awarded,
        user: {
          handle: user.handle,
          streak: newStreak,
          solvedIds,
          failCount: newFailCount,
          activityDays
        },
        squads: rows.map(formatSquadRow)
      };
    });

    logger.info("Submission processed atomically", { handle, problemId, passed, awarded: payload.awarded });
    res.json(payload);
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.message });
    next(err);
  }
};
