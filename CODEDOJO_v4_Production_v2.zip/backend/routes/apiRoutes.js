const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");
const dojoController = require("../controllers/dojoController");
const { authenticateJWT, optionalJWT } = require("../middleware/auth");
const {
  validateLogin,
  validateSquad,
  validateSquadMember,
  validateSubmission
} = require("../middleware/validation");

// Auth Routes
router.post("/auth/login", validateLogin, authController.loginOrRegister);
router.get("/auth/me", authenticateJWT, authController.getMe);

// Daily Problem & Leaderboard Routes
router.get("/daily", dojoController.getDailyChallenge);
router.get("/leaderboard", dojoController.getLeaderboard);
router.get("/sync", dojoController.syncData);

// Transactional Squad & Submission Routes
router.post("/squads", optionalJWT, validateSquad, dojoController.manageSquad);
router.post("/squads/members", authenticateJWT, validateSquadMember, dojoController.addSquadMember);
router.post("/submissions", authenticateJWT, validateSubmission, dojoController.submitSolution);

module.exports = router;
