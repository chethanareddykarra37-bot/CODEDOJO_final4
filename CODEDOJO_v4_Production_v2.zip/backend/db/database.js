const sqlite3 = require("sqlite3").verbose();
const { DB_PATH } = require("../config/env");
const logger = require("../utils/logger");

class DatabasePool {
  constructor(dbFile) {
    this.db = new sqlite3.Database(dbFile, (err) => {
      if (err) {
        logger.error("Failed to open SQLite database", { error: err.message });
      } else {
        logger.info("Connected to SQLite database", { path: dbFile });
      }
    });
    this.db.configure("busyTimeout", 5000);
  }

  run(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.run(sql, params, function (err) {
        if (err) return reject(err);
        resolve({ lastID: this.lastID, changes: this.changes });
      });
    });
  }

  get(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.get(sql, params, (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });
  }

  all(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.all(sql, params, (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });
  }

  async withTransaction(workFn) {
    await this.run("BEGIN IMMEDIATE TRANSACTION");
    try {
      const result = await workFn(this);
      await this.run("COMMIT");
      return result;
    } catch (err) {
      try {
        await this.run("ROLLBACK");
      } catch (rbErr) {
        logger.error("Transaction rollback error", { error: rbErr.message });
      }
      throw err;
    }
  }

  async init() {
    await this.run("PRAGMA journal_mode = WAL");
    await this.run("PRAGMA foreign_keys = ON");

    await this.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        handle TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        streak INTEGER DEFAULT 1,
        last_solved_date TEXT DEFAULT NULL,
        solved_ids TEXT DEFAULT '[]',
        fail_count INTEGER DEFAULT 0,
        activity_days TEXT DEFAULT '[0,0,1,1,2,1,2,1,3,2,4,1,2,0]',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await this.run(`
      CREATE TABLE IF NOT EXISTS squads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        access_code TEXT NOT NULL,
        members TEXT DEFAULT '[]',
        solves INTEGER DEFAULT 0,
        streak_bonus INTEGER DEFAULT 20,
        score INTEGER DEFAULT 20,
        last_snippet TEXT DEFAULT ''
      )
    `);

    await this.run(`
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_handle TEXT NOT NULL,
        problem_id TEXT NOT NULL,
        language TEXT DEFAULT 'javascript',
        passed INTEGER NOT NULL,
        points_awarded INTEGER DEFAULT 0,
        code TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await this.run("CREATE INDEX IF NOT EXISTS idx_squads_score ON squads(score DESC)");
    await this.run("CREATE INDEX IF NOT EXISTS idx_submissions_user ON submissions(user_handle)");

    const row = await this.get("SELECT COUNT(*) AS count FROM squads");
    if (row && row.count === 0) {
      await this.run(
        "INSERT INTO squads (name, access_code, members, solves, streak_bonus, score, last_snippet) VALUES (?, ?, ?, ?, ?, ?, ?)",
        ["Binary Beasts", "DOJO2026", JSON.stringify(["aarav_cs", "diya_dev", "rohan_algo"]), 4, 60, 460, "function solve(nums, target) { const s = new Set(); for (const n of nums) { if (s.has(target - n)) return true; s.add(n); } return false; }"]
      );
      await this.run(
        "INSERT INTO squads (name, access_code, members, solves, streak_bonus, score, last_snippet) VALUES (?, ?, ?, ?, ?, ?, ?)",
        ["Stack Overflowers", "STACK99", JSON.stringify(["meera_py", "kabir_ts"]), 3, 40, 340, "function solve(nums, target) { for (let i=0;i<nums.length;i++) for (let j=i+1;j<nums.length;j++) if (nums[i]+nums[j]===target) return true; return false; }"]
      );
    }
  }
}

const pool = new DatabasePool(DB_PATH);
pool.ready = pool.init();

module.exports = pool;
