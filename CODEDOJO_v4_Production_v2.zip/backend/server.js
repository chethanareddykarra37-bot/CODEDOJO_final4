const express = require("express");
const helmet = require("helmet");
const path = require("path");
const { PORT } = require("./config/env");
const logger = require("./utils/logger");
const apiRoutes = require("./routes/apiRoutes");

const app = express();

// Strict CSP without 'unsafe-inline'
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "blob:"],
        workerSrc: ["'self'", "blob:"],
        styleSrc: ["'self'"],
        imgSrc: ["'self'", "data:"],
        connectSrc: ["'self'", "http://localhost:*", "http://127.0.0.1:*"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        frameAncestors: ["'none'"]
      }
    }
  })
);

app.use(express.json({ limit: "64kb" }));

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  if (req.method === "OPTIONS") return res.sendStatus(200);
  next();
});

// Serve Static Frontend Files
app.use(express.static(path.join(__dirname, "..")));

// API Router
app.use("/api", apiRoutes);

// Centralized Error Middleware
app.use((err, req, res, _next) => {
  logger.error("Unhandled API Error", { path: req.path, error: err.message });
  res.status(err.status || 500).json({ error: err.message || "Internal Server Error" });
});

if (require.main === module) {
  app.listen(PORT, () => {
    logger.info(`CodeDojo Enterprise Server listening on http://localhost:${PORT}`);
  });
}

module.exports = app;
