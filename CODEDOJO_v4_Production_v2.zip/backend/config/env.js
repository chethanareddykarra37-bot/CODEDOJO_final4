const crypto = require("crypto");
const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../../.env") });

const NODE_ENV = process.env.NODE_ENV || "development";
const PORT = parseInt(process.env.PORT, 10) || 3000;
const DB_PATH = process.env.DB_PATH
  ? path.resolve(process.cwd(), process.env.DB_PATH)
  : path.resolve(__dirname, "../db/codedojo.sqlite");

let JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  if (NODE_ENV === "production") {
    throw new Error("FATAL: JWT_SECRET environment variable must be set in production.");
  }
  // Ephemeral runtime secret so no static secret is ever hardcoded in source
  JWT_SECRET = crypto.randomBytes(32).toString("hex");
}

module.exports = {
  NODE_ENV,
  PORT,
  DB_PATH,
  JWT_SECRET
};
